#pragma once

#include "ShaderWnd/external/glm/glm.hpp"

using namespace glm;

typedef vec4 point4;
typedef vec4 color4;

typedef vec3 point3;
typedef vec3 color3;